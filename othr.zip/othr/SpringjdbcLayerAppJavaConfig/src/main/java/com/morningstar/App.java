package com.morningstar;

import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.morningstar.config.AppConfig;
import com.morningstar.dao.StudentDao;
import com.morningstar.dao.StudentDaoImpl;
import com.morningstar.model.Student;
import com.morningstar.service.StudentService;
import com.morningstar.service.StudentServiceImpl;

public class App 
{
    public static void main( String[] args )
    {
    	//step 1: Get handle of Spring container
    	ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
    	
    	
    	
    	StudentService service=context.getBean(StudentService.class);
    	
    	Student student2=context.getBean(Student.class);
    	student2.setStudentId(109);
    	student2.setStudentName("Aniket");
    	student2.setStudentScore(80);
    	service.addStudent(student2);
    	System.out.println("Added");
    	
    	/*List<Student> result=service.findAllStudents();
    	for(Student student : result) {
    		System.out.println("Student Id "+ student.getStudentId());
    		System.out.println("Student Name "+student.getStudentName());
    		System.out.println("Student Score: "+student.getStudentScore());
    		System.out.println("-----------------------------------------");
    	}*/
    }
}
