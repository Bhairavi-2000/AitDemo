package com.morningstar.controler;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path="hello")
public class HelloRestController {

	//Restendpoint
	//http://localhost:8086/hello/welcome //context path is '' thats why we are not writing project name
	@GetMapping(path="welcome")
	public String hello() {
		return "Welcome to Spring Rest";
	}
	
	
	//http://localhost:8086/hello/user
	@GetMapping(path="user")
	public User greet() {
		User user=new User("Bhairavi","Bhole");
		return user;
	}
}
