package com.morningstar.dao;

import java.sql.SQLException;
import java.util.List;

import com.morningstar.model.Student;

public interface StudentDao {
	public int createStudent(Student student) throws SQLException;
	public Student readStudentById(int studentId) throws SQLException;
	public List<Student> readAllStudents() throws SQLException;
	public Student readStudentByName(String name) throws SQLException;
	public int deleteStudent(int studentId) throws SQLException;
	public int UpdateStudent(Student student) throws SQLException;
	public Student findStudentByMax() throws SQLException;
	public List<Student> findAllStudentsBetMinMax(int min, int max)throws SQLException;
	public List<Student> findPassedStudent()throws SQLException;
	public List<Student> findFailedStudent()throws SQLException;
}
