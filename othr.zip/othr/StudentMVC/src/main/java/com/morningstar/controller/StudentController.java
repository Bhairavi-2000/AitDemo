package com.morningstar.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.morningstar.model.Student;
import com.morningstar.service.StudentService;


@Controller
public class StudentController {

	@Autowired
	private StudentService service;
	
	@GetMapping(path="/")
	public String hello() {
		return "index";
	}
	
	@GetMapping(path="addStudentForm.view")
	public String studentForm() {
		return "addStudent";
	}
	
	@PostMapping(path="addStudent.do")
	public String addStudent(Student student) {
		boolean result= service.addStudent(student);
		if(result)
			return "redirect:viewStudent.do"; //redirector to controller
		else
			return "";
	}
	
	@GetMapping(path = "viewStudent.do")
	public String getAllStudents(Model model) {
		List<Student> students = service.findAllStudents();
		model.addAttribute("studentList", students);
		return "viewStudent";
	}
	
	//----------------------------------------ById-------------------------------------------
	@GetMapping(path="getById.veiw")
	public String getById() {
		return "getById";
	}
	@PostMapping("getStudent.do")
	public String getStudentById(int studentId, Model model) {
		Student student=service.findByStudentId(studentId);
		model.addAttribute( "Student",student);
		return "viewStudentById";
	}
	//-------------------------------------By Name-----------------------------//
	@GetMapping(path="getByName.veiw")
	public String getByName() {
		return "getByName";
	}
	@PostMapping("getStudentByName.do")
	public String getStudentByName(String studentName, Model model) {
		Student student=service.readStudentByName(studentName);
		model.addAttribute( "Student",student);
		return "viewStudentByName";
	}
	//--------------------------------DeleteStudent--------------------------------------------------
	@GetMapping("deleteStudent.veiw")
	public String deleteSudent() {
		return "getIdForDeleteStudent";
	}
	
	@PostMapping("DeleteStudent.do")
	public String deleteSudentById(int studentId ) {
		boolean result=service.deleteStudent(studentId);
		
		return "deleteStudent";
		
	}
//----------------------------Update student--------------------------------------
	@GetMapping("Update.veiw")
	public String Update() {
		return "getUpdatedStudent";
	}
	
	@PostMapping("update.do")
	public String UpdateStudent(Student student, Model model) {
		boolean result=service.UpdateStudent(student);
		return "updateStudent";
	}
	//-------------------------findBetweenMinMax-----------------------------
	@GetMapping("minmax.view")
	public String findBetMinMax(Model model) {
		List<Student> students = service.findAllStudentsBetMinMax(60,80);
		model.addAttribute("studentList", students);
		return "viewStudent";
	}
	
	//--------------------Max marks-----------------------------------------------------------
		@GetMapping("max.view")
		public String FindBymax(Model model) {
		Student student=service.findStudentByMax();
		model.addAttribute( "Student",student);
		return "viewStudentById"; //uses jsp page of view student by id to display student
	}
		//--------------------Passed Student-----------------------------------------------------------
		@GetMapping("pass.do")
		public String passedStudents(Model model) {
			List<Student> students = service.findPassedStudent();
			model.addAttribute("studentList", students);
			return "viewStudent";
		}
		
		
		//--------------------failed Student-----------------------------------------------------------
		@GetMapping("fail.do")
		public String failedStudents(Model model) {
			List<Student> students = service.findFailedStudent();
			model.addAttribute("studentList", students);
			return "viewStudent";
		}
}
