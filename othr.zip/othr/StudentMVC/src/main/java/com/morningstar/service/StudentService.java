package com.morningstar.service;

import java.util.List;

import com.morningstar.model.Student;

public interface StudentService {
	public boolean addStudent(Student student);
	public Student findByStudentId(int studentId);
	public List<Student> findAllStudents();
	public Student readStudentByName(String name);
	public boolean deleteStudent(int studentId);
	public boolean UpdateStudent(Student student);
	public Student findStudentByMax();
	public List<Student> findAllStudentsBetMinMax(int min, int max);
	public List<Student> findPassedStudent();
	public List<Student> findFailedStudent();
}
