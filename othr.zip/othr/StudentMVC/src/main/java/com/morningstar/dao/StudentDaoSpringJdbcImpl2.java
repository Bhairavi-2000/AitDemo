package com.morningstar.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.morningstar.model.Student;

public class StudentDaoSpringJdbcImpl2 implements StudentDao {

	@Autowired
	private JdbcTemplate template = null;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public int createStudent(Student student) throws SQLException {
		String query = "Insert into Student(Student_Id, Student_Name, Student_Score) values(?,?,?)";

		int result = template.update(query, student.getStudentId(), student.getStudentName(),
				student.getStudentScore());
		return result;
	}

	@Override
	public Student readStudentById(int studentId) throws SQLException {
		String query = "select * from student where student_Id=" + studentId;
		Student student = template.queryForObject(query, new StudentRowMapper());
		return student;
	}

	@Override
	public List<Student> readAllStudents() throws SQLException {
		String query = "select * from student";

		List<Student> list = template.query(query, (ResultSet rs, int rowNum) -> {

			Student student = new Student();
			student.setStudentId(rs.getInt("student_id"));
			student.setStudentName(rs.getString("Student_Name"));
			student.setStudentScore(rs.getDouble("Student_Score"));
			return student;

		});
		return list;
	}

	@Override
	public Student readStudentByName(String name) throws SQLException {
		String query = "select * from student where student_Name='" + name + "'";
		Student student = template.queryForObject(query, new StudentRowMapper());
		return student;
	}

	@Override
	public int deleteStudent(int studentId) throws SQLException {
		String query = "delete from  student where student_id=" + studentId;

		int result = template.update(query);
		return result;
	}

	@Override
	public int UpdateStudent(Student student) throws SQLException {
		String query = "Update Student set student_Name=?, student_Score=? where student_id=?";
		int result = template.update(query, student.getStudentName(), student.getStudentScore(),
				student.getStudentId());
		return result;
	}

	@Override
	public Student findStudentByMax() throws SQLException {

		String query = "select * from student where Student_Score=(select max(Student_Score) from student)";
		Student student = template.queryForObject(query, new StudentRowMapper());
		return student;
	}

	@Override
	public List<Student> findAllStudentsBetMinMax(int min, int max) throws SQLException {
		String query = "select * from student where student_score between " + min + " and " + max;

		List<Student> list = template.query(query, (ResultSet rs, int rowNum) -> {

			Student student = new Student();
			student.setStudentId(rs.getInt("student_id"));
			student.setStudentName(rs.getString("Student_Name"));
			student.setStudentScore(rs.getDouble("Student_Score"));
			return student;

		});
		return list;
	}

	@Override
	public List<Student> findPassedStudent() throws SQLException {

		String query = "select * from student where Student_Score >=60";
		List<Student> list = template.query(query, (ResultSet rs, int rowNum) -> {

			Student student = new Student();
			student.setStudentId(rs.getInt("student_id"));
			student.setStudentName(rs.getString("Student_Name"));
			student.setStudentScore(rs.getDouble("Student_Score"));
			return student;

		});
		return list;

	}

	@Override
	public List<Student> findFailedStudent() throws SQLException {
		String query="select * from student where Student_Score <"
				+ "60";
			List<Student> list=template.query(query, (ResultSet rs, int rowNum) -> {
			
			Student student=new Student();
			student.setStudentId(rs.getInt("student_id"));	
			student.setStudentName(rs.getString("Student_Name"));
			student.setStudentScore(rs.getDouble("Student_Score"));
		return student;
			
		});
		return list;
	}

}
