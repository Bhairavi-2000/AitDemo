package com.morningstar.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.morningstar.dao.StudentDao;

import com.morningstar.model.Student;
@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentDao dao = null;

	public StudentDao getDao() {
		return dao;
	}

	public void setDao(StudentDao dao) {
		this.dao = dao;
	}

	@Override
	public boolean addStudent(Student student) {
		try {
			int result = dao.createStudent(student);
			if (result >= 1) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public Student findByStudentId(int studentId) {

		Student student = null;
		try {
			student = dao.readStudentById(studentId);
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return student;
	}

	@Override
	public List<Student> findAllStudents() {
		List<Student> list = null;
		try {
			list = dao.readAllStudents();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return list;
	}

	@Override
	public Student readStudentByName(String name) {
		
		try {
			return dao.readStudentByName(name);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean deleteStudent(int studentId) {
		
		try {
			int result=dao.deleteStudent(studentId);
			if(result >=1)
				return true;
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean UpdateStudent(Student student) {
		try {
			int result=dao.UpdateStudent(student);
			if(result >=1)
				return true;
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public Student findStudentByMax() {
		try {
			return dao.findStudentByMax();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Student> findAllStudentsBetMinMax(int min, int max) {
		
		try {
			return dao.findAllStudentsBetMinMax(min, max);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Student> findPassedStudent() {
		
		try {
			return dao.findPassedStudent();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Student> findFailedStudent() {
		
		try {
			return dao.findFailedStudent();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
