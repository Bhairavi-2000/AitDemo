package com.morningstar;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.morningstar.model.Employee;

public class App 
{
    public static void main( String[] args )
    {
    	BeanFactory factory=new ClassPathXmlApplicationContext("spring-config.xml");
    	
    	Employee employee=factory.getBean(Employee.class);
    	System.out.println(employee);
    }
}
