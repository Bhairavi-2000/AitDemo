package com.morningstar.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.morningstar.model.Employee;

@Configuration
public class AppConfig {

	@Bean
	@Scope(scopeName = "singleton")
	public Employee getStudent() {
		Employee employee=new Employee(2,"Rutuja",60000,"r@gmail.com","27/05/09");
		return employee;
	}
}
