package com.morningstar.dao;


import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.morningstar.model.Student;
import com.morningstar.utility.JpaUtility;


public class StudentDaoImpl implements StudentDao{
	private EntityManager em=null;
	public StudentDaoImpl() {
		em=JpaUtility.getEntityManager();
	}
	
	
	@Override
	public int createStudent(Student student) throws SQLException {
		em.getTransaction().begin();
		em.persist(student);
		em.getTransaction().commit();
		return 1;
	}

	@Override
	public Student readStudentById(int studentId) throws SQLException {
		
		return em.find(Student.class, studentId);
	}

	@Override
	public List<Student> readAllStudents() throws SQLException {
		String jpql="Select s from Student s";
		TypedQuery<Student> tQuery= em.createQuery(jpql, Student.class);
		List<Student> list=	tQuery.getResultList();
		return list;
	}
	@Override
	public int deleteStdentById(int studentId) throws SQLException {
		String jpql="delete from Student s where s.studentId="+studentId;
		
		em.getTransaction().begin();
		int result =em.createQuery(jpql).executeUpdate();
		
		em.getTransaction().commit();
		return result;
	}


	@Override
	public boolean updateStudent(Student newStudent) {
		em.getTransaction().begin();
		em.merge(newStudent);
		em.getTransaction().commit();
		return true;
	}


	@Override
	public List<Student> findByName(String name) throws SQLException {
		String jpql="Select s from Student s where s.studentName="+"'"+name+"'";
		TypedQuery<Student> tQuery= em.createQuery(jpql, Student.class);
		List<Student> list=	tQuery.getResultList();
		return list;
		
	}


	@Override
	public List<Student> findByMinMaxScore(double min, double max) throws SQLException {
		String jpql="Select s from Student s where s.studentScore between :min and :max";
		Query query= em.createQuery(jpql);
		query.setParameter("min",min );
		query.setParameter("max",max );
		List<Student> list=	query.getResultList();
		return list;
	}


	@Override
	public Student findByMaxScore() throws SQLException {
		String jpql="Select s from Student s order by s.studentScore =(select max(s.studentScore) from Student s);";
		Query query=em.createQuery(jpql, Student.class);
		Class<? extends Query> student=query.getClass();
		
		
		return null;
	}


	@Override
	public List<Student> failedStudent() throws SQLException {
		Query query=em.createQuery("select s from Student s where s.studentScore < 60");
		List<Student> list=query.getResultList();
		return list;
	}


	@Override
	public List<Student> passedStudent() throws SQLException {
		Query query=em.createQuery("select s from Student s where s.studentScore >= 60");
		List<Student> list=query.getResultList();
		return list;
	}
	

}
