package com.morningstar.service;

import java.sql.SQLException;
import java.util.List;

import com.morningstar.model.Student;

public interface StudentService {
	public boolean addStudent(Student student);
	public Student findByStudentId(int studentId);
	public List<Student> findAllStudents();
	public boolean deleteStdentById(int studentId) ;
	public boolean updateStudent(Student newStudent);
	public List<Student>findByName(String name);
	public List<Student>findByMinMaxScore(double min, double max) throws SQLException;
	public Student findByMaxScore();
	public List<Student> failedStudent();
	public List<Student> passedStudent();
}
