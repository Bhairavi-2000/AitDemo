package com.morningstar.dao;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.engine.jdbc.spi.SqlExceptionHelper;

import com.morningstar.model.Student;

public interface StudentDao {
	
	public int createStudent(Student student) throws SQLException;
	public Student readStudentById(int studentId) throws SQLException;
	public List<Student> readAllStudents() throws SQLException;
	public int deleteStdentById(int studentId) throws SQLException;
	public boolean updateStudent(Student newStudent);
	public List<Student> findByName(String name) throws SQLException; 
	public List<Student>findByMinMaxScore(double min, double max) throws SQLException;
	public Student findByMaxScore() throws SQLException;
	public List<Student> failedStudent() throws SQLException;
	public List<Student> passedStudent() throws SQLException;
}
