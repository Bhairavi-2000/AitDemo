package com.morningstar.service;

import java.sql.SQLException;
import java.util.List;

import com.morningstar.dao.StudentDao;
import com.morningstar.model.Student;

public class StudentServiceImpl implements StudentService{

	private StudentDao dao;
	
	public StudentDao getDao() {
		return dao;
	}

	public void setDao(StudentDao dao) {
		this.dao = dao;
	}

	@Override
	public boolean addStudent(Student student) {
		try {
			int result=dao.createStudent(student);
			if(result==1)
				return true;
		} catch (SQLException e) {
			
			e.printStackTrace();
			
		}
		return false;
		
	}

	@Override
	public Student findByStudentId(int studentId) {
		
		try {
			return dao.readStudentById(studentId);
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Student> findAllStudents() {
		
		try {
			return dao.readAllStudents();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean deleteStdentById(int studentId) {
		try {
			int result=dao.deleteStdentById(studentId);
			if(result >=1)
				return true;
		} catch (SQLException e) {
			
			e.printStackTrace();
			
		}
		return false;
	}

	@Override
	public boolean updateStudent(Student newStudent) {
		return 	dao.updateStudent(newStudent);
	
	}

	@Override
	public List<Student> findByName(String name) {
		try {
			return dao.findByName(name);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Student> findByMinMaxScore(double min, double max)  {
		
		try {
			return dao.findByMinMaxScore(min, max);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Student findByMaxScore()  {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> failedStudent(){
		
		try {
			return dao.failedStudent();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Student> passedStudent(){
		try {
			return dao.passedStudent();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
