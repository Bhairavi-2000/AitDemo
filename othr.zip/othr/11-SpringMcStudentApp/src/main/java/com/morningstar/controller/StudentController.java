package com.morningstar.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.morningstar.model.Student;
import com.morningstar.service.StudentService;


@Controller
public class StudentController {

	@Autowired
	private StudentService service;
	
	@GetMapping
	public String hello() {
		return "index";
	}
	
	@GetMapping(path="addStudentForm.view")
	public String studentForm() {
		return "addStudent";
	}
	
	@PostMapping(path="addStudent.do")
	public String addStudent(Student student) {
		boolean result= service.addStudent(student);
		if(result)
			return "redirect:viewStudent.do"; //redirector to controller
		else
			return "";
	}
	
	@GetMapping(path = "viewStudent.do")
	public String getAllStudents(Model model) {
		List<Student> students = service.findAllStudents();
		model.addAttribute("studentList", students);
		return "viewStudent";
	}

}
