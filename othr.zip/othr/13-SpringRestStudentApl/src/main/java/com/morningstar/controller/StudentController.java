package com.morningstar.controller;

import java.util.List;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.morningstar.model.Student;
import com.morningstar.service.StudentService;

import ch.qos.logback.core.status.Status;

@RestController
@RequestMapping(path="student")
public class StudentController {

	@Autowired
	private StudentService service;
	
	
	//http://localhost:8088/student-api/student/getAll
	@GetMapping(path="getAll")
	public List<Student> getAllStudent() {
		List<Student> studentList=service.findAllStudents();
		return studentList;
	}
	
	
	//http://localhost:8088/student-api/student/add
	@PostMapping(path="add")
	public void addStdent(@RequestBody Student student) {
		boolean result= service.addStudent(student);
		ResponseEntity<String> response=null;
		if(result)
			response=new ResponseEntity<String>("Student is added",HttpStatus.CREATED);
		else
			response=new ResponseEntity<String>("Student is not added",HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
