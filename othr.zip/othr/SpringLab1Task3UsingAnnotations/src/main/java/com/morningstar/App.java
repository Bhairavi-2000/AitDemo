package com.morningstar;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.morningstar.config.AppConfig;
import com.morningstar.model.Employee;

public class App 
{
    public static void main( String[] args )
    {
    	BeanFactory factory=new AnnotationConfigApplicationContext(AppConfig.class);
    	
    	Employee employee=factory.getBean(Employee.class);
    	System.out.println(employee);
    	System.out.println(employee.getDept());
    }
}
