package com.morningstar.model;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Employee {

	private int employeeId;
	private String employeeName;
	private double employeeSalary;
	private String employeeEmail;
	private String employeeDOJ;
	@Autowired
	private Department dept;
	
	public Employee() {
		this.employeeId = 1;
		this.employeeName = "Bhairavi";
		this.employeeSalary = 60000;
		this.employeeEmail = "b@gmail.com";
		this.employeeDOJ = "22-08-2021";
	}

	public Employee(int employeeId, String employeeName, double employeeSalary, String employeeEmail,
			String employeeDOJ) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
		this.employeeEmail = employeeEmail;
		this.employeeDOJ = employeeDOJ;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public double getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public String getEmployeeEmail() {
		return employeeEmail;
	}

	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}

	public String getEmployeeDOJ() {
		return employeeDOJ;
	}

	public void setEmployeeDOJ(String employeeDOJ) {
		this.employeeDOJ = employeeDOJ;
	}
	

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeSalary="
				+ employeeSalary + ", employeeEmail=" + employeeEmail + ", employeeDOJ=" + employeeDOJ + "]";
	}
	
}
