package com.morningstar;

import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.morningstar.dao.StudentDao;
import com.morningstar.dao.StudentDaoImpl;
import com.morningstar.model.Student;
import com.morningstar.service.StudentService;
import com.morningstar.service.StudentServiceImpl;

public class AppAutowiredByName 
{
    public static void main( String[] args )
    {
    	//step 1: Get handle of Spring container
    	BeanFactory factory=new ClassPathXmlApplicationContext("spring-config2-autowired-By-Name.xml");
    	
    	
    	
    	StudentService service=factory.getBean(StudentService.class);
    	
    	List<Student> result=service.findAllStudents();
    	for(Student student : result) {
    		System.out.println("Student Id "+ student.getStudentId());
    		System.out.println("Student Name "+student.getStudentName());
    		System.out.println("Student Score: "+student.getStudentScore());
    		System.out.println("-----------------------------------------");
    	}
    }
}
