package com.morningstar.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.morningstar.model.Address;
import com.morningstar.model.Student;

@Configuration
public class AppConfig {

	@Bean
	@Scope(scopeName = "singleton")
	public Student getStudent() {
		Student student=new Student(1,"Bhairavi", 89);
		Address add=new Address(1, "Pune", "452008");
		student.setAddress(add);
		return student;
	}
}
