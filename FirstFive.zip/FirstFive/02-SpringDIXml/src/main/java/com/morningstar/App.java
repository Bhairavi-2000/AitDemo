package com.morningstar;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.morningstar.model.Student;

public class App 
{
    public static void main( String[] args )
    {
    	//step 1: Get handle of Spring container
    	BeanFactory factory=new ClassPathXmlApplicationContext("spring-config.xml");
    	
    	// step 2: will ask for student object for spring container
    	Student student=factory.getBean(Student.class);
    	
    	// step 3: use the object
    	System.out.println(student);
    	System.out.println(student.getAddress());
    }
}
