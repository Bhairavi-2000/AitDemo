package com.morningstar;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.morningstar.model.Student;
import com.morningstar.service.StudentService;

@SpringBootApplication
public class Main2 {

	public static void main(String[] args) {
		ApplicationContext context=SpringApplication.run(Main2.class, args);
		StudentService service=context.getBean(StudentService.class);
		List<Student> result=service.findAllStudents();
		for(Student s:result) {
			System.out.println(s);
		}
	}

}
