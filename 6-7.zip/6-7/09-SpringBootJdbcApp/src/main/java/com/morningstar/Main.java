package com.morningstar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.morningstar.model.Student;
import com.morningstar.service.StudentService;

//@Configuration
//@ComponentScan
//@EnableAutoConfiguration

@SpringBootApplication
public class Main {

	public static void main(String[] args) {
		ApplicationContext context=SpringApplication.run(Main.class, args);
		StudentService service=context.getBean(StudentService.class);
		
	/*	Student student=context.getBean(Student.class);
		student.setStudentId(113);
		student.setStudentName("Siya");
		student.setStudentScore(86);
		service.addStudent(student);
		System.out.println("Student is added");*/
		
		Student result=service.findByStudentId(113);
		System.out.println(result);
	}

}
