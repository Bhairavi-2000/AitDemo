package com.morningstar.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.morningstar.model.Student;

@Repository
class StudentDaoImpl2 implements StudentDao{

	@Override
	public int createStudent(Student student) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Student readStudentById(int studentId) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> readAllStudents() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
