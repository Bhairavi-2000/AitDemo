package com.morningstar.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.morningstar.model.Student;

@Repository("dao") //Name of the bean
public class StudentDaoImpl implements StudentDao {

	private static Connection connection = null;

	static {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
			connection.setAutoCommit(false);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("There is some problem");
			e.printStackTrace(); // log the stack trace
		}

	}

	public static Connection getConnection() {
		return connection;
	}

	@Override
	public int createStudent(Student student) throws SQLException {
		String sql = "insert into Student(Student_Id, Student_Name, Student_Score) values(?,?,?)";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setInt(1, student.getStudentId());
		pstmt.setString(2, student.getStudentName());
		pstmt.setDouble(3, student.getStudentScore());
		int result = pstmt.executeUpdate();
		pstmt.close();
		return result;
	}

	@Override
	public Student readStudentById(int studentId) throws SQLException {
		String sql = "Select * from Student where Student_Id=" + studentId;
		Statement stmt = connection.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		Student student = null;
		if (rs.next()) {
			int studId = rs.getInt("student_Id");
			String studentName = rs.getString("student_Name");
			double studentScore = rs.getDouble("student_Score");
			student = new Student(studId, studentName, studentScore);
		}
		stmt.close();
		return student;
	}

	@Override
	public List<Student> readAllStudents() throws SQLException {
		String sql = "Select * from Student";
		Statement stmt = connection.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		 List<Student> list= new ArrayList<>();
		while (rs.next()) {
			int studId = rs.getInt("student_Id");
			String studentName = rs.getString("student_Name");
			double studentScore = rs.getDouble("student_Score");
			Student student = new Student(studId, studentName, studentScore);
			list.add(student);
		}
		return list;
	}

}
